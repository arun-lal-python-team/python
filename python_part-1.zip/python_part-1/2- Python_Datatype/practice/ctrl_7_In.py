Dynamic Access Control System (Cybersecurity & IT)
🔹 Use Case: Determines access level based on user role and security clearance.

python
Copy
Edit
# User role and security clearance
user_role = input("Enter your role (admin, manager, employee, guest): ").strip().lower()
security_clearance = int(input("Enter your security clearance level (1-5): "))

# Access control logic
if user_role == "admin" and security_clearance >= 5:
    print("🔓 Full Access Granted!")
elif user_role in ["manager", "employee"] and security_clearance >= 3:
    print("✅ Limited Access Granted.")
elif user_role == "guest" and security_clearance >= 1:
    print("🔒 Guest Access Only.")
else:
    print("⛔ Access Denied!")
Concepts Used:
✔ if-elif-else for access control
✔ in operator for multiple role checks
✔ String normalization (strip().lower())
✔ Use Case: Enterprise security & authentication systems

2️⃣ Fraud Detection in Banking (Finance & Risk Management)
🔹 Use Case: Flags suspicious transactions based on amount and location.

python
Copy
Edit
# Get transaction details
amount = float(input("Enter transaction amount: "))
location = input("Enter transaction location: ").strip().lower()
account_balance = 10000  # Example balance

# Fraud detection logic
if amount > 5000 or location not in ["usa", "canada", "uk"]:
    print("🚨 Potential Fraud Detected! Manual review required.")
elif amount > account_balance:
    print("❌ Transaction Declined! Insufficient funds.")
else:
    print("✅ Transaction Approved.")
Concepts Used:
✔ if-else for fraud detection
✔ Logical operators (or, not in)
✔ Hardcoded account balance simulation
✔ Use Case: Banking & fintech fraud detection systems

3️⃣ Smart Home Automation (IoT & AI)
🔹 Use Case: Controls home appliances based on temperature and time.

python
Copy
Edit
# Get environmental conditions
temperature = float(input("Enter room temperature in °C: "))
time_of_day = input("Enter time of day (morning, afternoon, night): ").strip().lower()

# Smart home automation logic
if temperature > 30:
    print("❄️ Turning ON air conditioner.")
elif temperature < 15:
    print("🔥 Turning ON heater.")
elif time_of_day == "night":
    print("💡 Dimming lights for night mode.")
else:
    print("✅ All systems are running normally.")
Concepts Used:
✔ if-elif-else for decision-making
✔ Dynamic user inputs for automation
✔ Use Case: IoT-based smart home systems

Summary
🔐 Access Control → IT security & authentication
💳 Fraud Detection → Finance & risk management
🏠 Smart Home Automation → IoT & AI-driven automation
