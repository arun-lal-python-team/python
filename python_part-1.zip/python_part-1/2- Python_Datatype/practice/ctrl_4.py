For an experienced Python developer, real-world use cases of if-else and for loops often involve data processing, automation, and decision-making. Here are three practical programs covering different domains:

1️⃣ Log File Error Analyzer (System Monitoring)
🔹 Use Case: Monitor system logs and flag critical errors.

python
Copy
Edit
# Sample log file data
log_data = [
    "[INFO] Server started successfully.",
    "[WARNING] High memory usage detected.",
    "[ERROR] Database connection failed.",
    "[INFO] User login successful.",
    "[ERROR] Disk space critically low.",
]

# Analyze log messages
for log in log_data:
    if "[ERROR]" in log:
        print(f"🚨 Critical Issue Found: {log}")
    elif "[WARNING]" in log:
        print(f"⚠️ Warning: {log}")
    else:
        print(f"✅ Normal Log: {log}")
Concepts Used:
if-else for classifying log messages
for loop to iterate over logs
String operations (in) for pattern matching
2️⃣ Customer Order Processing (E-commerce)
🔹 Use Case: Check order status and process bulk orders.

python
Copy
Edit
orders = [
    {"order_id": 101, "status": "pending", "amount": 250},
    {"order_id": 102, "status": "completed", "amount": 1500},
    {"order_id": 103, "status": "pending", "amount": 5000},
    {"order_id": 104, "status": "cancelled", "amount": 0},
]

# Process orders
for order in orders:
    if order["status"] == "completed":
        print(f"✅ Order {order['order_id']} is already completed.")
    elif order["status"] == "pending":
        print(f"🔄 Processing Order {order['order_id']} (Amount: ${order['amount']})...")
        if order["amount"] > 3000:
            print(f"🚀 Order {order['order_id']} qualifies for express shipping!")
    else:
        print(f"❌ Order {order['order_id']} is cancelled.")
Concepts Used:
for loop for bulk order processing
if-else for conditional checks
Nested if for special conditions (express shipping)
3️⃣ Employee Payroll Processing (HR Automation)
🔹 Use Case: Calculate employee salary after deductions and bonuses.

python
Copy
Edit
employees = [
    {"name": "Alice", "role": "Manager", "salary": 7000, "bonus": True},
    {"name": "Bob", "role": "Developer", "salary": 5000, "bonus": False},
    {"name": "Charlie", "role": "Intern", "salary": 2000, "bonus": False},
]

# Payroll Processing
for employee in employees:
    base_salary = employee["salary"]
    if employee["bonus"]:
        final_salary = base_salary + 1000  # Bonus added
    else:
        final_salary = base_salary
    
    print(f"💼 {employee['name']} ({employee['role']}) - Final Salary: ${final_salary}")

Concepts Used:
for loop to process multiple employees
if-else to handle salary calculations with bonuses
Dictionary operations for structured data

Conclusion
✅ Log File Analyzer → System monitoring
✅ Order Processing → E-commerce automation
✅ Payroll Processing → HR automation

Would you like a database integration or API-based automation added? 🚀