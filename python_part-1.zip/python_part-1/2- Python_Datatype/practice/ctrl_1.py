# Python Control Statement Practice Program

# 1. If-Else Statements
print("If-Else Statements Example:")
x = 10
if x > 0:
    print(f"{x} is positive")
elif x == 0:
    print(f"{x} is zero")
else:
    print(f"{x} is negative")

# 2. Nested If-Else Statements
print("\nNested If-Else Example:")
y = 15
if y > 10:
    if y % 2 == 0:
        print(f"{y} is even and greater than 10")
    else:
        print(f"{y} is odd and greater than 10")
else:
    print(f"{y} is less than or equal to 10")

# 3. For Loop with a List
print("\nFor Loop with a List Example:")
fruits = ["apple", "banana", "cherry", "date"]
for fruit in fruits:
    print(fruit)

# 4. For Loop with Range
print("\nFor Loop with Range Example:")
for i in range(5, 11):  # From 5 to 10 (inclusive)
    print(i)

# 5. While Loop
print("\nWhile Loop Example:")
count = 1
while count <= 5:
    print(f"Count is {count}")
    count += 1

# 6. Break Statement in Loop
print("\nBreak Statement Example:")
for num in range(1, 11):
    if num == 6:
        print("Breaking the loop when number is 6")
        break
    print(num)

# 7. Continue Statement in Loop
print("\nContinue Statement Example:")
for num in range(1, 11):
    if num % 2 == 0:
        continue  # Skip the even numbers
    print(num)

# 8. While Loop with an else block
print("\nWhile Loop with Else Example:")
counter = 0
while counter < 5:
    print(f"Counter is {counter}")
    counter += 1
else:
    print("Counter has reached 5, exiting the loop")

# 9. Using `and`, `or` operators in if conditions
print("\nUsing `and`, `or` operators Example:")
a = 5
b = 10
if a < b and b > 5:
    print("Both conditions are true: a < b and b > 5")

if a > 3 or b < 5:
    print("At least one condition is true: a > 3 or b < 5")

# 10. Using a combination of loops and conditionals (Fibonacci sequence)
print("\nFibonacci Sequence Example:")
n_terms = 10
a, b = 0, 1
print("Fibonacci Sequence:")
for _ in range(n_terms):
    print(a, end=" ")
    a, b = b, a + b
