Here are three real-world Python programs using basic if-else statements, designed for a 5-year-experience developer but keeping it simple and practical. These examples cover different domains: authentication, e-commerce discounts, and weather-based recommendations.

1️⃣ User Authentication System
This program checks a username and password against predefined credentials.

# Simple User Authentication
stored_username = "admin"
stored_password = "secure123"

# User Input
username = input("Enter username: ")
password = input("Enter password: ")

# Authentication Check
if username == stored_username and password == stored_password:
    print("✅ Access Granted! Welcome to the system.")
else:
    print("❌ Access Denied! Invalid credentials.")


Concepts Used:
if-else for authentication
and logical operator
input() for user interaction



2️⃣ E-commerce Discount System
A simple discount system based on the purchase amount.

# Get the purchase amount
amount = float(input("Enter purchase amount: "))

# Discount Calculation
if amount >= 5000:
    discount = amount * 0.20  # 20% discount
elif amount >= 3000:
    discount = amount * 0.15  # 15% discount
elif amount >= 1000:
    discount = amount * 0.10  # 10% discount
else:
    discount = 0  # No discount

final_amount = amount - discount

# Output the final price
print(f"Original Amount: ${amount:.2f}")
print(f"Discount Applied: ${discount:.2f}")
print(f"Final Payable Amount: ${final_amount:.2f}")


Concepts Used:
if-elif-else structure for conditional logic
Basic arithmetic operations
Formatting output using :.2f (for 2 decimal places)

3️⃣ Weather-Based Outfit Suggestion
This program suggests outfits based on the temperature.

python
Copy
Edit
# Get temperature input
temperature = int(input("Enter today's temperature in °C: "))

# Outfit Suggestion
if temperature > 30:
    print("🔥 It's hot outside! Wear light clothing and stay hydrated.")
elif 20 <= temperature <= 30:
    print("☀️ The weather is pleasant. A t-shirt and jeans would be perfect.")
elif 10 <= temperature < 20:
    print("🌤️ It's a bit chilly. Wear a light jacket.")
else:
    print("❄️ It's cold! Wear a heavy coat and stay warm.")


Concepts Used:

Temperature-based conditions
if-elif-else for multiple possibilities
Readable and user-friendly messages


Conclusion
Each of these programs uses basic if-else conditions but in practical, real-world scenarios:

✔ Authentication → Security & login systems
✔ E-commerce Discounts → Retail & pricing logic
✔ Weather Suggestion → Smart assistant & recommendation systems

Would you like to modify or extend any of these? 🚀









