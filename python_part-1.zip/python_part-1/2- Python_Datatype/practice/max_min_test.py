import basic

def test_min():
    
         values = (2, 3, 1, 4, 6)
         val = basic.min(values)
         assert val == 1,  "Test Case Failes"

def test_max():
    
         values = (2, 3, 1, 4, 6)
         val = basic.max(values)
         assert val == 6
