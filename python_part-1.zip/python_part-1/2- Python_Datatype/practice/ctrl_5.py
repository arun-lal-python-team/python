1️⃣ Utility Bill Calculator (Electricity Billing)
🔹 Use Case: A program to calculate electricity bills based on consumption.

python
Copy
Edit
# Get electricity usage from the user
units = float(input("Enter electricity units consumed: "))

# Define billing rates
if units <= 100:
    bill = units * 5  # $5 per unit for first 100 units
elif units <= 300:
    bill = (100 * 5) + (units - 100) * 7  # $7 per unit for next 200 units
else:
    bill = (100 * 5) + (200 * 7) + (units - 300) * 10  # $10 per unit above 300 units

# Display the total bill
print(f"⚡ Your total electricity bill is: ${bill:.2f}")
Concepts Used:
✔ if-elif-else for range-based pricing
✔ Arithmetic calculations
✔ .2f formatting for currency display

2️⃣ Student Grading System
🔹 Use Case: Assigns grades based on student marks.

python
Copy
Edit
# Get marks from the user
marks = int(input("Enter student marks (0-100): "))

# Assign grade
if marks >= 90:
    grade = "A+"
elif marks >= 80:
    grade = "A"
elif marks >= 70:
    grade = "B"
elif marks >= 60:
    grade = "C"
elif marks >= 50:
    grade = "D"
else:
    grade = "F"

# Output result
print(f"📖 Student Grade: {grade}")
Concepts Used:
✔ if-elif-else for multi-level decision making
✔ Integer comparison (>=)
✔ User-friendly message formatting


=============
====================================================
