def experience_level():
    print("Welcome to the Python Experience Level Assessment!")
    
    score = 0  # Track the experience level

    # Question 1: If-Else Statement
    answer = input("Q1: What will be the output of 'print(10 > 5)'? (True/False): ").strip().lower()
    if answer == "true":
        score += 1
    else:
        print("Incorrect! The correct answer is True.")

    # Question 2: For Loop
    print("\nQ2: What will be printed by the following code?")
    print("for i in range(3): print(i)")
    answer = input("Enter the output separated by spaces (e.g., '0 1 2'): ").strip()
    if answer == "0 1 2":
        score += 1
    else:
        print("Incorrect! The correct output is '0 1 2'.")

    # Question 3: While Loop
    print("\nQ3: What will be the value of 'x' after this code runs?")
    print("x = 0\nwhile x < 3:\n    x += 1")
    answer = input("Enter the final value of x: ").strip()
    if answer == "3":
        score += 1
    else:
        print("Incorrect! The correct answer is 3.")

    # Question 4: Break Statement
    print("\nQ4: What will be printed by the following code?")
    print("for i in range(5):\n    if i == 3:\n        break\n    print(i)")
    answer = input("Enter the output separated by spaces (e.g., '0 1 2'): ").strip()
    if answer == "0 1 2":
        score += 1
    else:
        print("Incorrect! The correct output is '0 1 2'.")

    # Question 5: Continue Statement
    print("\nQ5: What will be printed by the following code?")
    print("for i in range(5):\n    if i == 2:\n        continue\n    print(i)")
    answer = input("Enter the output separated by spaces (e.g., '0 1 3 4'): ").strip()
    if answer == "0 1 3 4":
        score += 1
    else:
        print("Incorrect! The correct output is '0 1 3 4'.")

    # Evaluating Experience Level
    print("\nYour Score:", score, "/ 5")
    if score == 5:
        print("You are an **Advanced** Python programmer! 🚀")
    elif score >= 3:
        print("You are an **Intermediate** Python programmer. Keep practicing! 👍")
    else:
        print("You are a **Beginner** in Python. Keep learning! 📘")

# Run the program
experience_level()
