 Automated Email Spam Filter (Cybersecurity)
🔹 Use Case: A simple spam detection system that classifies emails as spam or not based on certain words.

python
Copy
Edit
# Define spam keywords
spam_keywords = ["win", "free", "prize", "urgent", "lottery", "click here"]

# Sample email content (In a real-world scenario, fetch from an email API)
email_subject = input("Enter email subject: ").lower()
email_body = input("Enter email body: ").lower()

# Check if email contains spam keywords
is_spam = False
for keyword in spam_keywords:
    if keyword in email_subject or keyword in email_body:
        is_spam = True
        break  # Stop checking if one keyword is found

# Output result
if is_spam:
    print("🚨 This email is classified as SPAM.")
else:
    print("✅ This email is safe.")
Concepts Used:
✔ if-else for classification
✔ for loop for keyword matching
✔ lower() for case-insensitive search
✔ Email filtering logic used in security systems

2️⃣ Loan Approval System (Finance & Banking)
🔹 Use Case: Determines whether a person qualifies for a loan based on income, credit score, and existing loans.

python
Copy
Edit
# Get user financial details
income = float(input("Enter your annual income: "))
credit_score = int(input("Enter your credit score (300-850): "))
existing_loans = int(input("Enter number of existing loans: "))

# Loan approval criteria
if income > 50000 and credit_score >= 700 and existing_loans == 0:
    print("✅ Loan Approved!")
elif income > 30000 and credit_score >= 650 and existing_loans <= 1:
    print("⚠️ Loan Approved with higher interest rate.")
else:
    print("❌ Loan Denied. Improve credit score or income.")
Concepts Used:
✔ if-elif-else for decision-making
✔ and logical operator for multi-condition checks
✔ Banking logic for loan approval
✔ Can be extended with database integration

3️⃣ Automated Ticket Pricing System (Transport & Travel)
🔹 Use Case: Calculates ticket prices dynamically based on age, travel time, and peak hours.

python
Copy
Edit
# Get user details
age = int(input("Enter your age: "))
travel_time = input("Enter travel time (peak/off-peak): ").strip().lower()

# Define base fare
fare = 10  # Default fare in $

# Apply discounts or surcharges
if age < 12 or age > 60:
    fare *= 0.5  # 50% discount for children and seniors
elif travel_time == "peak":
    fare *= 1.2  # 20% extra charge during peak hours

print(f"🚆 Your ticket price is: ${fare:.2f}")
Concepts Used:
✔ if-else for conditional pricing
✔ String handling (strip().lower()) for flexible input
✔ Multiplication for discounts & surcharges
✔ Real-world application in public transport systems

Summary
🔐 Spam Filter → Cybersecurity & AI-based filtering
💰 Loan System → Finance & Banking automation
🚆 Ticket Pricing → Dynamic pricing in Transport
Would you like to enhance these with APIs, databases, or machine learning? 🚀







