Fraud Detection System: If-Else Example
Features:
Checks if the transaction amount exceeds a set limit.
Flags transactions from high-risk countries.
Verifies if the transaction is happening from an unusual location or device.
Alerts the user if multiple failed attempts occur.


class FraudDetection:
    def __init__(self, user_id, transaction_amount, country, device, failed_attempts):
        self.user_id = user_id
        self.transaction_amount = transaction_amount
        self.country = country
        self.device = device
        self.failed_attempts = failed_attempts
        self.suspicious = False

    def analyze_transaction(self):
        high_risk_countries = {"North Korea", "Iran", "Syria", "Cuba"}
        transaction_limit = 5000  # Threshold amount in USD

        # Rule 1: Check if amount is suspiciously high
        if self.transaction_amount > transaction_limit:
            print(f"ALERT: High transaction amount detected (${self.transaction_amount})")
            self.suspicious = True

        # Rule 2: Check if transaction is from a high-risk country
        if self.country in high_risk_countries:
            print(f"ALERT: Transaction from a high-risk country ({self.country})")
            self.suspicious = True

        # Rule 3: Check for unusual device login
        if self.device not in ["Mobile", "Laptop", "Tablet"]:
            print(f"ALERT: Unusual device detected ({self.device})")
            self.suspicious = True

        # Rule 4: Multiple failed attempts before a transaction
        if self.failed_attempts > 3:
            print(f"ALERT: Multiple failed attempts detected ({self.failed_attempts})")
            self.suspicious = True

        # Final decision
        if self.suspicious:
            print("⚠️ FRAUD ALERT: Transaction requires manual verification!")
        else:
            print("✅ Transaction is safe.")

# Example Usage
transaction_1 = FraudDetection(user_id=101, transaction_amount=6000, country="USA", device="Mobile", failed_attempts=1)
transaction_2 = FraudDetection(user_id=102, transaction_amount=200, country="North Korea", device="Smartwatch", failed_attempts=5)

print("\nTransaction 1 Analysis:")
transaction_1.analyze_transaction()

print("\nTransaction 2 Analysis:")
transaction_2.analyze_transaction()

Key Takeaways
✔ Uses if-else logic to check multiple fraud scenarios.
✔ Helps detect suspicious transactions based on predefined rules.
✔ Mimics real-world fraud detection used in banks & fintech apps.

Would you like to enhance this with AI-based detection or database integration?
