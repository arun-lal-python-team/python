'''
1:Wap to insert employee details in the form of one key and value as [name , cont,email ,salary]
 
  A:display all employee details
  B: Search by eid , if eid present then display employee details and if eid not present the show message
     “Employee Not present”.

'''

info_Dict={}
employee={}

def add_record(emp_no):

    for employees in range(0,emp_no):
        id=input("enter the id")
        if employees>0:
            while id in employee:
                k=input("key already taken by another employee:")

        info_Dict["Name"]=input("Name:")
        info_Dict["Salary"]=input("salary:")
        info_Dict["Email"]=input("email:")

        employee[""+id]=(info_Dict)
    
    print(employee)

def checkKey(employee, key):
     
    if key in employee.keys():
        print("Present, ", end =" ")
        print("name of employee=", "\t", "employee salary", "\t","employee email", employee[key])
        for x in info_Dict:
            print(x,"\t\t",info_Dict[x])
    else:
        print("Not present")
 
 

# checkKey(employee, key)

choice = input("Enter the id of employee to search for")
print(" For insert record : 1")
print("For find employee : 2")

match choice:
            
            case 1:
                emp_no=int(input("enter the number of entries"))
                add_record(emp_no)
                
            case 2:
                key = input("Enter the id of employee to search for")
                checkKey(employee,key)
                
            case _ :
                print("Enter Correct Choice")
