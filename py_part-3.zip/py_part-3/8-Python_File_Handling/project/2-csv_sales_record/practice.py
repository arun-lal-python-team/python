from fastapi import FastAPI, Depends, HTTPException, status
"""
This module implements a FastAPI application for user authentication using JWT tokens.
The application includes the following functionalities:
- User login to generate an access token.
- Retrieve current user information based on the access token.
Dependencies:
- FastAPI: Web framework for building APIs.
- Pydantic: Data validation and settings management using Python type annotations.
- jose: JavaScript Object Signing and Encryption (JOSE) for JWT token encoding and decoding.
Modules:
- fastapi: FastAPI framework and dependencies.
- pydantic: BaseModel for data validation.
- typing: Optional type hinting.
- datetime: Date and time manipulation.
- jose: JWT token encoding and decoding.
Constants:
- SECRET_KEY: Secret key used to encode and decode JWT tokens.
- ALGORITHM: Algorithm used for JWT token encoding.
- ACCESS_TOKEN_EXPIRE_MINUTES: Token expiration time in minutes.
Functions:
- verify_password: Verifies if the provided password matches the hashed password.
- get_user: Retrieves a user from the database.
- authenticate_user: Authenticates a user by verifying the username and password.
- create_access_token: Creates a JWT access token with an optional expiration time.
- get_current_user: Dependency to get the current user from the token.
- get_current_active_user: Dependency to get the current active user.
Routes:
- /token (POST): Generates an access token for the user.
- /users/me (GET): Retrieves the current user's information based on the access token.
"""
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timedelta
from jose import JWTError, jwt

# Secret key to encode and decode JWT tokens
SECRET_KEY = "your_secret_key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Initialize FastAPI app
app = FastAPI()

# OAuth2 scheme for token-based authentication
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# In-memory user storage for demonstration purposes
fake_users_db = {
    "user@example.com": {
        "username": "user@example.com",
        "full_name": "John Doe",
        "email": "user@example.com",
        "hashed_password": "fakehashedpassword",
        "disabled": False,
    }
}

# Pydantic models for request and response bodies
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

class User(BaseModel):
    username: str
    email: str
    full_name: Optional[str] = None
    disabled: Optional[bool] = None

class UserInDB(User):
    hashed_password: str

# Function to verify password
def verify_password(plain_password, hashed_password):
    return plain_password == hashed_password

# Function to get user from the database
def get_user(db, username: str):
    if username in db:
        user_dict = db[username]
        return UserInDB(**user_dict)

# Function to authenticate user
def authenticate_user(fake_db, username: str, password: str):
    user = get_user(fake_db, username)
    if not user:
        return False
    if not verify_password(password, user.hashed_password):
        return False
    return user

# Function to create access token
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

# Dependency to get the current user from the token
async def get_current_user(token: str = Depends(oauth2_scheme)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
        token_data = TokenData(username=username)
    except JWTError:
        raise credentials_exception
    user = get_user(fake_users_db, username=token_data.username)
    if user is None:
        raise credentials_exception
    return user

# Dependency to get the current active user
async def get_current_active_user(current_user: User = Depends(get_current_user)):
    if current_user.disabled:
        raise HTTPException(status_code=400, detail="Inactive user")
    return current_user

# Route to generate token
@app.post("/token", response_model=Token)
async def login_for_access_token(form_data: OAuth2PasswordRequestForm = Depends()):
    user = authenticate_user(fake_users_db, form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user.username}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

# Route to get current user information
@app.get("/users/me", response_model=User)
async def read_users_me(current_user: User = Depends(get_current_active_user)):
    if current_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return current_user