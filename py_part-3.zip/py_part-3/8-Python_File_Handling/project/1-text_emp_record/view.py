
import constants

def add_employee():

    # Adding employees
    emp_id=int(input("Please enter employee id :"))
    emp_name=input("Please enter employee name :")
    emp_dep=input("Please enter employee department :")
    emp_esal=int(input("Please enter employee salary :"))
    with open(f'data/{constants.EMPLOYEE_FILE}', 'a') as file:
        file.write(f"{emp_id},{emp_name},{emp_dep},{emp_esal}\n")

# Display all employees records
def display_employees():

    with open(f'data/{constants.EMPLOYEE_FILE}', 'r') as file:
        employees = file.readlines()
        if employees:
            print("Employee Records:")
            for employee in employees:
                print(employee.strip())
        else:
            print("No employee records found.")

# Update an employee's salary by emp_id.
def update_employee_salary():

    emp_id=input("Please enter employee id :")
    new_salary=int(input("Please enter employee salary :"))

    with open(f'data/{constants.EMPLOYEE_FILE}', 'r') as file:
        employees = file.readlines()
        print('****',employees)

    with open(f'data/{constants.EMPLOYEE_FILE}', 'w') as file:
        for employee in employees:
            emp_details = employee.strip().split(',')
            if emp_details[0] == emp_id:
                print("ID found ")
                emp_details[3] = new_salary  # Update salary
                file.write((str(emp_details)))
                # file.write(emp_details)
            else:
                file.write(employee)

# Function to delete an employee by emp_id
def delete_employee(emp_id):
    with open(f'data/{constants.EMPLOYEE_FILE}', 'r') as file:
        employees = file.readlines()

    with open(f'data/{constants.EMPLOYEE_FILE}', 'w') as file:
        for employee in employees:
            emp_details = employee.strip().split(',')
            if emp_details[0] != emp_id:
                file.write(employee)

