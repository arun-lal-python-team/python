
import os
import constants
from controllers import employee_controller


print("*"*70)
print("$ Welcome in Employee Management  System $")
print("!"*70)

# Function to ensure the file exists
def ensure_file_exists():
    if not os.path.exists(constants.EMPLOYEE_FILE):
        with open(f'data/{constants.EMPLOYEE_FILE}', 'w') as f:
            pass  # Just create the file if it doesn't exist

ensure_file_exists()
employee_controller()
