
#Employee Constants

ADD_EMPLOYEE= 1
DISPLAY_EMPLOYEE= 2
UPDATE_EMPLOYEE_SALARY= 3
DELETE_EMPLOYEE= 4

# Define the file name for storing employee records
EMPLOYEE_FILE = "employees.txt"
