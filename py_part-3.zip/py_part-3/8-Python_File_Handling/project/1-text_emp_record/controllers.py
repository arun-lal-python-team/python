import constants
from view import(
    add_employee, display_employees,
    update_employee_salary
)  
def employee_controller():

    operation_choice= int(input("Select the choice for operation: "))

    match operation_choice:

        case constants.ADD_EMPLOYEE:
            add_employee()
        case constants.DISPLAY_EMPLOYEE:
            display_employees()
        case constants.UPDATE_EMPLOYEE_SALARY:
            update_employee_salary()
        case constants.DELETE_EMPLOYEE:
            print("It's 20")
        case _:
            print("Please select valid choice")
    